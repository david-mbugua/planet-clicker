"use strict"

const playnow = document.querySelector("#playnow")

playnow.addEventListener("click",  ()=>{
    ExitApi.exit(window.clickTag); 
}) 